import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RobotStructureComponent } from './robot-structure/robot-structure.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import {OverlayPanelModule} from 'primeng/overlaypanel';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {TooltipModule} from 'primeng/tooltip';
import {DialogModule} from 'primeng/dialog';
import {ButtonModule} from 'primeng/button';
import { FormsModule } from '@angular/forms';
import {InputTextModule} from 'primeng/inputtext';

@NgModule({
  declarations: [
    AppComponent,
    RobotStructureComponent
  ],
  imports: [
    BrowserModule,
    InputTextModule,
    ButtonModule,
    DialogModule,
    TooltipModule,
    AppRoutingModule,
    FlexLayoutModule,
    OverlayPanelModule,
    BrowserAnimationsModule,
    FormsModule      
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
