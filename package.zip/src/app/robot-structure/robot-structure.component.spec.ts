import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RobotStructureComponent } from './robot-structure.component';

describe('RobotStructureComponent', () => {
  let component: RobotStructureComponent;
  let fixture: ComponentFixture<RobotStructureComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RobotStructureComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RobotStructureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
