import { Component, OnInit } from '@angular/core';
import { OverlayPanel } from 'primeng/overlaypanel';
import { Constant } from '../const';

@Component({
  selector: 'app-robot-structure',
  templateUrl: './robot-structure.component.html',
  styleUrls: ['./robot-structure.component.css']
})
export class RobotStructureComponent implements OnInit {

  robotStructureArray: any = [{ 0: ["", "", "DD1", "DD2"] }, { 1: ["CR", null, "PS", "DD3"] }, { 2: ["LT2", null, "MVS", ""] }, { 3: ["UL", "HS", "LPM"] }, { 4: ["ASRS", "", ""] }];;
  robotStructureStationDetails: any = Constant.ROBOT_STRUCTURE_COMPONENT_DETAILS;
  displayDetails: boolean = false;
  selectedStation: string = "";
  position: string = "";
  carExistStation: any = [];
  addRemoveButtonLabel: string = "Add Car";
  changePositionDialogDisplay: boolean = false;
  positionRequired: boolean = false;
  positionInvalid: boolean = false;
  positionLengthError: boolean = false;
  confirmationDisplay: boolean = false;

  constructor() { }

  ngOnInit(): void {
  }

  showStationDetails(station: any, check: boolean) {
    if (!station) {
      this.displayDetails = false;
    }
    else {
      this.displayDetails = check;
    }
    if(station)
    {
      this.selectedStation = station;
    }
    else
    {
      this.selectedStation="";
    }
    if (this.carExistStation.indexOf(station)!=-1) {
      this.addRemoveButtonLabel = "Remove Car";
    }
    else {
      this.addRemoveButtonLabel = "Add Car";
    }
  }

  confirm() {
    if (this.carExistStation.indexOf(this.selectedStation)==-1) {
      this.carExistStation.push(this.selectedStation);
    }
    else {
      this.carExistStation.splice(this.carExistStation.indexOf(this.selectedStation),1);
    }
    this.selectedStation = "";
    this.confirmationDisplay = false;
  }

  hideShowAddCarDialog(check: boolean) {
    this.confirmationDisplay = check;
    if (check == false) {
      this.displayDetails = true;
    }
    else {
      this.displayDetails = false;
    }
  }

  showHideChangePositionDialog(hideShow: boolean) {
    this.changePositionDialogDisplay = hideShow;
    this.positionRequired = false;
    this.positionInvalid = false;
    this.positionLengthError = false;
    this.position = "";
    if (hideShow == false) {
      this.displayDetails = true;
      let element = document.getElementById("changePositionId");
      if (element) {
        element.classList.remove("ng-touched");
        element.classList.add("ng-untouched");
      }
    }
    else {
      this.displayDetails = false;
    }
  }

  checkPositionValidation() {
    if (this.position) {
      this.positionRequired = false;
      if (!this.robotStructureStationDetails[this.position]) {
        this.positionInvalid = true;
      }
      else {
        this.positionInvalid = false;
        if (this.robotStructureStationDetails[this.position]["length"] != this.robotStructureStationDetails[this.selectedStation]["length"]) {
          this.positionLengthError = true;
        }
        else {
          this.positionLengthError = false;
        }
      }
    }
    else {
      this.positionRequired = true;
      this.positionInvalid = false;
    }
  }

  changePosition() {
    if (!this.positionInvalid && !this.positionRequired && !this.positionLengthError) {
      let indexOfPosition = -1;
      let indexOfSelectedPosition = -1;
      for (let count = 0; count < this.robotStructureArray.length; count++) {
        for (let countInnerArray = 0; countInnerArray < this.robotStructureArray[count][count].length; countInnerArray++) {
          if (this.robotStructureArray[count][count][countInnerArray] == this.position) {
            this.robotStructureArray[count][count][countInnerArray] = this.selectedStation;
            indexOfPosition = 0;
          }
          else if (this.robotStructureArray[count][count][countInnerArray] == this.selectedStation) {
            this.robotStructureArray[count][count][countInnerArray] = this.position;
            indexOfSelectedPosition = 0;
          }
          if (indexOfSelectedPosition != -1 && indexOfPosition != -1) {
            this.displayDetails = false;
            this.selectedStation = "";
            this.changePositionDialogDisplay = false;
            break;
          }
        }
      }
    }
  }

  addRemoveCar() {
    this.carExistStation.push(this.selectedStation);
  }

}
